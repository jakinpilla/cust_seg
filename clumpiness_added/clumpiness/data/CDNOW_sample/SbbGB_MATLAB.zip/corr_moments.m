% corr_moments.m
Mu = [params(1) params(2)];
R  = [params(3) params(4); 0 params(5)];
Y = Z*R; 
logitp = Y(:,1) + Mu(1);
p = exp(logitp)./(1+exp(logitp));
logitt = Y(:,2) + Mu(2);
t = exp(logitt)./(1+exp(logitt));
EP = mean(p); VP = mean(p.*p)-EP^2;
ET = mean(t); VT = mean(t.*t)-ET^2;
covPT = mean(p.*t)-EP*ET; corrPT = covPT/sqrt(VP*VT);