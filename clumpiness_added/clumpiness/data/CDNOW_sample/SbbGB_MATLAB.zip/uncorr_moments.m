% uncorr_moments.m
Mu = [params(1) params(2)];
Sigma  = diag([params(3) params(4)]);
Y = Z*sqrt(Sigma); 
logitp = Y(:,1) + Mu(1);
p = exp(logitp)./(1+exp(logitp));
logitt = Y(:,2) + Mu(2);
t = exp(logitt)./(1+exp(logitt));
EP = mean(p); VP = mean(p.*p)-EP^2;
ET = mean(t); VT = mean(t.*t)-ET^2;
