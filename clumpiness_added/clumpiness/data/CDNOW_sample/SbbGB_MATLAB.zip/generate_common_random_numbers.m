% generate_common_random_numbers.m
global Z
randn('state',100); % set the seed for purposes of replication   
Z = randn(100000,2);
