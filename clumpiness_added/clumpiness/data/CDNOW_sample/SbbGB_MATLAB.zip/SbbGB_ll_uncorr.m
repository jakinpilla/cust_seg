function [f,g]= SbbGB_ll_uncorr(param)
% SbbGB_ll_uncorr.m -- evaluate the log-likelihood
% function for the uncorrelated S_BB-G/B model 
global x tx n num Z
%
% Part A
Mu = [param(1) param(2)];
Sigma = diag([param(3) param(4)]);
Y = Z*sqrt(Sigma); 
logitp = Y(:,1) + Mu(1);
p = exp(logitp)./(1+exp(logitp));
logitt = Y(:,2) + Mu(2);
t = exp(logitt)./(1+exp(logitt));
%
% Part B
lik = [];
for i = 1:22
   tmp_lik = p.^x(i).*(1-p).^(n(i)-x(i)).*(1-t).^(n(i));
   for j = 0:(n(i)-tx(i)-1)
      tmp_lik = tmp_lik + p.^x(i).*(1-p).^(tx(i)...
          -x(i)+j).*t.*(1-t).^(tx(i)+j);
   end;
   ll(i) = log(mean(tmp_lik));
end;
%
f = -ll*num;
[f/1000 param]
g=[];
