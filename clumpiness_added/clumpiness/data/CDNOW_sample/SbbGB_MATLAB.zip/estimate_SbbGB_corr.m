% estimate_SbbGB_corr.m
lb = -10*ones(1,5);
ub =  10*ones(1,5);
initial = .1*ones(1,5);
[params ll] = fmincon('SbbGB_ll_corr',initial,[],[],[],[],lb,ub)