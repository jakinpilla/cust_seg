% create_basic_plot_numbers.m

%*************************************
%* Compute E[X(n)] for tracking plot *
%*************************************

EX = [];
for s = 1:11
    EX(s) = mean(p.*(1-t)./t - p.*(1-t).^(s+1)./t);
end


%*********************
%* Compute P(X(n)=x) *
%*********************

ms = 6; % time period for computation of probabilities (n)
PX = [];
for s = 0:ms
   tmp_PX = nchoosek(ms,s).*p.^s...
       .*(1-p).^(ms-s).*(1-t).^ms;
   for j = s:(ms-1)
      tmp_PX = tmp_PX + nchoosek(j,s).*p.^s.*(1-p).^(j-s).*t...
          .*(1-t).^j;      
   end;
   PX(s+1) = mean(tmp_PX); 
end;


%***************************
%* Compute P(X(n,n+n*)=x*) *
%***************************

ms = 5; % time period for computation of probabilities (n*)
PXf = [];
for s = 0:ms
   tmp_PXf = (s==0)*(1-(1-t).^(max(n))) + nchoosek(ms,s).*p.^s...
       .*(1-p).^(ms-s).*(1-t).^(max(n)+ms);
   for j = s:(ms-1)
      tmp_PXf = tmp_PXf + nchoosek(j,s).*p.^s.*(1-p).^(j-s).*t...
          .*(1-t).^(max(n)+j);      
   end;
   PXf(s+1) = mean(tmp_PXf); 
end;
