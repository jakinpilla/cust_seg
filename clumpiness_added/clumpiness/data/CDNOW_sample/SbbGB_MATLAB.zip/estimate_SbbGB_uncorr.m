% estimate_SbbGB_uncorr.m
lb = -10*[1 1 0 0];
lb(3) = .0001; lb(4)= .0001;
ub =  10*[1 1 1 1];
initial = .1*ones(1,4);
initial = 1*ones(1,4);

[params ll] = fmincon('SbbGB_ll_uncorr',initial,[],[],[],[],lb,ub)
