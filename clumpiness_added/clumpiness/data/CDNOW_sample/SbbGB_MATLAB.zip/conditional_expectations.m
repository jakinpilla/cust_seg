% conditional_expectations.m
%
m = 5; % time horizon for conditional expectation 
CE  = [];
for i = 1:22
   tmp_lik = p.^x(i).*(1-p).^(n(i)-x(i)).*(1-t).^(n(i));
   tmp_CE  = (p.*(1-t)./t - p.*(1-t).^(m+1)./t).*tmp_lik ;
   for j = 0:(n(i)-tx(i)-1)
      tmp_lik = tmp_lik + p.^x(i).*(1-p).^(tx(i)-x(i)+j).*...
          t.*(1-t).^(tx(i)+j);      
   end;
   lik = mean(tmp_lik); 
   CE(i)  = mean(tmp_CE)/lik;      
end;
